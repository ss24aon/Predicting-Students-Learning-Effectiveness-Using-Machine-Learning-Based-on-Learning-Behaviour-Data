import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent


class Config:
    # Default to a dev key, but allow overriding via env for deployment.
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key")

    UPLOAD_FOLDER = BASE_DIR / "data"

    MODELS_DIR = BASE_DIR / "models"
    MODEL_PATH = MODELS_DIR / "best_model.pkl"
    SCALER_PATH = MODELS_DIR / "scaler.pkl"
    ENCODER_PATH = MODELS_DIR / "encoders.pkl"
    FEATURES_PATH = MODELS_DIR / "features.pkl"

    GRAPHS_DIR = BASE_DIR / "static" / "graphs"
