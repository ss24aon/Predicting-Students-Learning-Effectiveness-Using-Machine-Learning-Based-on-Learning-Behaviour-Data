import os
import joblib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

from xgboost import XGBClassifier
from imblearn.over_sampling import SMOTE

from app.preprocessing import preprocess_data
from config import Config

MODEL_PATH = Config.MODEL_PATH
SCALER_PATH = Config.SCALER_PATH
ENCODER_PATH = Config.ENCODER_PATH
FEATURES_PATH = Config.FEATURES_PATH

Config.MODELS_DIR.mkdir(parents=True, exist_ok=True)
Config.GRAPHS_DIR.mkdir(parents=True, exist_ok=True)

# ======================
# TRAIN FUNCTION
# ======================

def train(df):

    X, y, scaler, encoders, feature_names = preprocess_data(df)

    # Handle imbalance
    smote = SMOTE()
    X, y = smote.fit_resample(X, y)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    models = {
        "RandomForest": RandomForestClassifier(),
        "GradientBoost": GradientBoostingClassifier(),
        "XGBoost": XGBClassifier(use_label_encoder=False, eval_metric='logloss')
    }

    results = []
    best_model = None
    best_acc = 0

    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)

        acc = accuracy_score(y_test, preds)

        results.append({"model": name, "accuracy": round(acc,3)})

        if acc > best_acc:
            best_acc = acc
            best_model = model
            best_preds = preds

    # Save
    joblib.dump(best_model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    joblib.dump(encoders, ENCODER_PATH)
    if feature_names is not None:
        joblib.dump(feature_names, FEATURES_PATH)

    # Graphs
    plot_accuracy(results)
    plot_confusion(y_test, best_preds)

    return results, best_acc

# ======================
# PREDICT FUNCTION
# ======================

def predict(features):

    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    encoders = {}
    try:
        encoders = joblib.load(ENCODER_PATH)
    except Exception:
        encoders = {}

    features = np.array(features).reshape(1, -1)
    features = scaler.transform(features)

    pred = model.predict(features)[0]

    target_encoder = encoders.get("__target__")
    if target_encoder is not None:
        try:
            return target_encoder.inverse_transform([pred])[0]
        except Exception:
            pass

    return pred

# ======================
# GRAPHS
# ======================

def plot_accuracy(results):
    names = [r["model"] for r in results]
    acc = [r["accuracy"] for r in results]

    plt.figure()
    plt.bar(names, acc)
    plt.title("Model Accuracy")
    plt.savefig(str(Config.GRAPHS_DIR / "accuracy.png"))
    plt.close()

def plot_confusion(y_test, preds):
    cm = confusion_matrix(y_test, preds)

    plt.figure()
    plt.imshow(cm)
    plt.title("Confusion Matrix")
    plt.colorbar()
    plt.savefig(str(Config.GRAPHS_DIR / "confusion.png"))
    plt.close()

def plot_prediction(pred):
    plt.figure()
    plt.pie([1,1], labels=[f"Class {pred}", "Other"], autopct="%1.1f%%")
    plt.title("Prediction")
    plt.savefig(str(Config.GRAPHS_DIR / "prediction.png"))
    plt.close()
