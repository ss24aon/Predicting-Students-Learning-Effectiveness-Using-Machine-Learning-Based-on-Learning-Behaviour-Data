import os
import pandas as pd
from flask import Blueprint, request, render_template, redirect
from werkzeug.utils import secure_filename

from app.ml import train, predict, plot_prediction

main = Blueprint("main", __name__)

UPLOAD_FOLDER = "data"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@main.route("/")
def home():
    return render_template("index.html")

@main.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@main.route("/upload", methods=["POST"])
def upload():

    file = request.files["file"]
    filename = secure_filename(file.filename)

    path = os.path.join(UPLOAD_FOLDER, filename)
    file.save(path)

    df = pd.read_csv(path)

    results, best_acc = train(df)

    generate_report(results, best_acc)

    return redirect("/report")

@main.route("/report")
def report():
    return render_template("report.html")

@main.route("/predict", methods=["POST"])
def make_prediction():

    data = list(map(float, request.form.getlist("features")))
    pred = predict(data)

    plot_prediction(pred)

    return f"""
    <h2>Prediction: {pred}</h2>
    <img src="/static/graphs/prediction.png" width="300">
    <br><br>
    <a href="/dashboard">Back</a>
    """

# ======================
# PURE HTML REPORT
# ======================

def generate_report(results, best_acc):

    rows = ""
    for r in results:
        rows += f"<tr><td>{r['model']}</td><td>{r['accuracy']}</td></tr>"

    html = f"""
    <html>
    <body>
    <h1>Model Report</h1>
    <h2>Best Accuracy: {best_acc}</h2>

    <table border="1">
    <tr><th>Model</th><th>Accuracy</th></tr>
    {rows}
    </table>

    <h2>Graphs</h2>
    <img src="/static/graphs/accuracy.png" width="400">
    <img src="/static/graphs/confusion.png" width="400">

    <br><br>
    <a href="/dashboard">Back</a>
    </body>
    </html>
    """

    with open("templates/report.html", "w") as f:
        f.write(html)