import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from pandas.api.types import is_numeric_dtype, is_string_dtype, is_categorical_dtype

# ==============================
# HANDLE MISSING VALUES
# ==============================
def _is_categorical(series: pd.Series) -> bool:
    # Treat pandas "string", "object", and "category" as categorical.
    return (
        is_string_dtype(series.dtype)
        or series.dtype == "object"
        or is_categorical_dtype(series.dtype)
    )


def handle_missing(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns:
        if _is_categorical(df[col]):
            # mode() can be empty for all-NA columns; fall back to empty string.
            mode = df[col].mode(dropna=True)
            fill_value = mode.iloc[0] if len(mode) else ""
            df[col] = df[col].fillna(fill_value)
        else:
            df[col] = df[col].fillna(df[col].mean(numeric_only=True))
    return df


# ==============================
# ENCODE CATEGORICAL FEATURES
# ==============================
def encode_categorical(df: pd.DataFrame):
    df = df.copy()
    encoders: dict[str, LabelEncoder] = {}

    for col in df.columns:
        if not is_numeric_dtype(df[col]) and _is_categorical(df[col]):
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            encoders[col] = le

    return df, encoders


# ==============================
# TARGET INFERENCE
# ==============================
def infer_target_column(df: pd.DataFrame) -> str:
    if df.shape[1] < 2:
        return df.columns[-1]

    normalized = {c: str(c).strip().lower() for c in df.columns}

    explicit_target_names = [
        "target",
        "label",
        "class",
        "y",
        "outcome",
        "result",
        "diagnosis",
    ]
    excluded_names = {"id", "uid", "index", "patient_id"}

    for col in df.columns:
        name = normalized[col]
        if name in explicit_target_names:
            return col

    n_rows = max(int(df.shape[0]), 1)
    max_unique = min(20, max(2, int(n_rows * 0.2)))

    low_cardinality_cols: list[str] = []
    for col in df.columns:
        name = normalized[col]
        if name in excluded_names:
            continue
        nunique = df[col].nunique(dropna=True)
        if nunique <= max_unique:
            low_cardinality_cols.append(col)

    # Prefer a single low-cardinality non-numeric column, otherwise fall back to last column.
    non_numeric_low = [c for c in low_cardinality_cols if not is_numeric_dtype(df[c])]
    if len(non_numeric_low) == 1:
        return non_numeric_low[0]

    return df.columns[-1]


# ==============================
# FEATURE ENGINEERING
# ==============================
def feature_engineering(X: pd.DataFrame) -> pd.DataFrame:
    X = X.copy()
    numeric_cols = [c for c in X.columns if is_numeric_dtype(X[c])]

    # Example features (adjust based on dataset)
    if len(numeric_cols) >= 2:
        a, b = numeric_cols[0], numeric_cols[1]
        X["interaction"] = X[a] * X[b]
        X["ratio"] = X[a] / (X[b] + 1)

    return X


# ==============================
# REMOVE OUTLIERS (IQR METHOD)
# ==============================
def remove_outliers(X: pd.DataFrame, y: pd.Series):
    numeric_cols = [c for c in X.columns if is_numeric_dtype(X[c])]
    if not numeric_cols:
        return X, y

    q1 = X[numeric_cols].quantile(0.25)
    q3 = X[numeric_cols].quantile(0.75)
    iqr = q3 - q1

    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr

    mask = ~((X[numeric_cols] < lower) | (X[numeric_cols] > upper)).any(axis=1)
    return X.loc[mask].reset_index(drop=True), y.loc[mask].reset_index(drop=True)


# ==============================
# SCALING
# ==============================
def scale_features(X):
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    feature_names = list(X.columns) if hasattr(X, "columns") else None
    return X_scaled, scaler, feature_names


# ==============================
# FULL PIPELINE
# ==============================
def preprocess_data(df):

    df = df.copy()

    # Step 1: Pick target (avoid accidentally treating labels like 'M'/'B' as features)
    target_col = infer_target_column(df)

    # Step 2: Split
    X = df.drop(columns=[target_col])
    y = df[target_col]

    # Step 3: Missing values
    X = handle_missing(X)
    y = y.fillna(y.mode(dropna=True).iloc[0] if len(y.mode(dropna=True)) else y.iloc[0])

    # Step 4: Encode categorical features
    X, feature_encoders = encode_categorical(X)

    # Step 5: Encode target if needed (kept under a reserved key)
    encoders = dict(feature_encoders)
    is_classification = False
    if not is_numeric_dtype(y) and _is_categorical(y):
        target_encoder = LabelEncoder()
        is_classification = True
        y = pd.Series(target_encoder.fit_transform(y.astype(str)), name=target_col)
        encoders["__target__"] = target_encoder

    # Step 6: Feature engineering (on features only)
    X = feature_engineering(X)

    # Step 7: Remove outliers (features only; keep y aligned)
    X, y = remove_outliers(X, y)

    # Step 8: Scale
    X_scaled, scaler, feature_names = scale_features(X)

    return X_scaled, y, scaler, encoders, is_classification, feature_names


# ==============================
# TRANSFORM NEW DATA (INFERENCE)
# ==============================
def transform_features(
    X: pd.DataFrame,
    scaler: StandardScaler,
    encoders: dict,
    *,
    expected_columns: list[str] | None = None,
) -> np.ndarray:
    """
    Apply the same feature-side preprocessing used during training:
    - missing value handling
    - categorical encoding using provided encoders
    - feature engineering
    - scaling

    Note: Outlier removal is intentionally NOT applied at inference.
    """
    if not isinstance(X, pd.DataFrame):
        X = pd.DataFrame(X)

    X = handle_missing(X)

    # Encode using fitted encoders (do not fit new ones).
    for col in X.columns:
        le = encoders.get(col)
        if le is None:
            if not is_numeric_dtype(X[col]) and _is_categorical(X[col]):
                raise ValueError(
                    f"Column '{col}' is categorical but has no fitted encoder. "
                    "Train the model on data that includes this column, or drop it at inference."
                )
            continue

        X[col] = le.transform(X[col].astype(str))

    X = feature_engineering(X)

    if expected_columns is not None:
        # Add missing expected columns and drop unexpected extras, then reorder.
        for col in expected_columns:
            if col not in X.columns:
                X[col] = 0
        X = X[[c for c in expected_columns if c in X.columns]]

    expected = getattr(scaler, "n_features_in_", None)
    if expected is not None and X.shape[1] != expected:
        raise ValueError(f"Expected {expected} features, got {X.shape[1]}.")

    return scaler.transform(X)
