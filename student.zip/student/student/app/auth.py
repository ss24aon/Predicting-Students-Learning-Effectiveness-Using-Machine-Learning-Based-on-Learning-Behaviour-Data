from flask import Blueprint, request, redirect, render_template
from flask_login import login_user, logout_user, UserMixin

auth = Blueprint("auth", __name__)

class User(UserMixin):
    def __init__(self, id):
        self.id = id

@auth.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        user = User("admin")
        login_user(user)
        return redirect("/dashboard")
    return render_template("login.html")

@auth.route("/logout")
def logout():
    logout_user()
    return redirect("/login")