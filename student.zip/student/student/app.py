import os
import joblib
import jwt
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import Flask, request, render_template, redirect, make_response
from app.preprocessing import preprocess_data
from werkzeug.utils import secure_filename

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import accuracy_score, r2_score


# =====================
# CONFIG
# =====================
app = Flask(__name__)
app.secret_key = "supersecretkey"

UPLOAD_FOLDER = "data"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs("static/graphs", exist_ok=True)

users = {}

# =====================
# GRAPH
# =====================
def plot_prediction(df):

    target = df.columns[-1]

    values = pd.to_numeric(df[target], errors='coerce').dropna()

    plt.figure(figsize=(5,5))

    if len(values) > 0:
        # 🔥 Convert to 3 segments
        low_th = values.quantile(0.33)
        high_th = values.quantile(0.66)

        low = (values < low_th).sum()
        medium = ((values >= low_th) & (values < high_th)).sum()
        high = (values >= high_th).sum()

        sizes = [low, medium, high]
        labels = ["Low", "Medium", "High"]

        # safety
        if sum(sizes) == 0:
            sizes = [1, 1, 1]

        colors = ["#ff4d4d", "#f9c74f", "#43aa8b"]

        plt.pie(
            sizes,
            labels=labels,
            autopct='%1.1f%%',
            colors=colors,
            startangle=140,
            wedgeprops={'edgecolor': 'white', 'linewidth': 2}
        )

        plt.title("Student Performance Distribution", fontsize=12)

    else:
        # categorical fallback
        counts = df[target].value_counts()

        counts = counts.head(5)

        plt.pie(
            counts.values,
            labels=counts.index,
            autopct='%1.1f%%',
            startangle=140,
            wedgeprops={'edgecolor': 'white', 'linewidth': 2}
        )

        plt.title("Top Categories")

    plt.tight_layout()
    plt.savefig("static/graphs/prediction.png")
    plt.close()

def plot_class_distribution(df):

    target = df.columns[-1]

    plt.figure(figsize=(4,4))

    if df[target].dtype == 'object':
        counts = df[target].value_counts()

        plt.pie(
            counts,
            labels=counts.index,
            autopct="%1.1f%%",
            startangle=140
        )

        plt.title("Class Distribution")

    else:
        df[target].plot(kind='hist', bins=10)
        plt.title("Target Distribution")

    plt.tight_layout()
    plt.savefig("static/graphs/class_dist.png")
    plt.close()

def plot_student_performance(student_analysis):

    counts = {"Low": 0, "Medium": 0, "High": 0}

    # 🔥 SAFE COUNTING
    for s in student_analysis:
        perf = str(s.get("performance", "")).strip()

        if perf in counts:
            counts[perf] += 1

    values = list(counts.values())

    # 🔥 FIX 1: Handle all zeros
    if sum(values) == 0:
        values = [1, 1, 1]

    labels = ["Low", "Medium", "High"]
    colors = ["#ff4d4d", "#ffc107", "#28a745"]

    plt.figure(figsize=(4,4))

    plt.pie(
        values,
        labels=labels,
        autopct="%1.1f%%",
        colors=colors,
        startangle=140
    )

    plt.title("Student Performance Overview")

    plt.savefig("static/graphs/student_perf.png")
    plt.close()

# =====================
# UNIVERSAL INSIGHTS
# =====================
def analyze_patterns(df):

    rec = []
    df.columns = df.columns.str.lower()

    target = df.columns[-1]

    # 🔥 Performance-based
    if df[target].dtype != 'object':
        avg = df[target].mean()

        if avg < df[target].quantile(0.4):
            rec.append("Overall performance is low → Increase study hours and revision")
        else:
            rec.append("Students performing well → Maintain consistency")

    # 🔥 Study time
    if "studytime" in df.columns:
        if df["studytime"].mean() < 2:
            rec.append("Students are not studying enough → Encourage daily study routine")

    # 🔥 Absences
    if "absences" in df.columns:
        if df["absences"].mean() > 5:
            rec.append("Attendance issues detected → Improve class participation")

    # 🔥 Failures
    if "failures" in df.columns:
        if df["failures"].mean() > 0:
            rec.append("Failure rate exists → Provide extra academic support")

    if not rec:
        rec.append("Learning patterns are stable → No major intervention needed")

    return rec

def analyze_students(df):

    results = []
    target = df.columns[-1]

    numeric_df = df.apply(pd.to_numeric, errors='coerce')

    # normalize
    norm_df = (numeric_df - numeric_df.mean()) / numeric_df.std()

    # 🔥 FIX: Pre-calculate quantiles
    q33 = numeric_df[target].quantile(0.33)
    q66 = numeric_df[target].quantile(0.66)

    for i in df.index:

        strengths = []
        weaknesses = []

        row = norm_df.loc[i]

        # 🔥 risk score (core logic)
        risk_score = 0

        # 🔥 FIX: Limit to top 5 features for analysis
        sorted_cols = row.abs().sort_values(ascending=False).head(5)

        for col in sorted_cols.index:

            if col == target:
                continue

            val = row[col]

            if pd.isna(val):
                continue

            # 🔥 FIX: More sensitive thresholds
            if val < -0.5:
                weaknesses.append(col)
                risk_score += abs(val)

            elif val > 0.5:
                strengths.append(col)

        # normalize risk (0–100)
        risk_score = min(int(risk_score * 25), 100)

        # 🎯 performance
        val = numeric_df.loc[i, target]

        if pd.notna(val):
            if val < q33:
                perf = "Low"
            elif val < q66:
                perf = "Medium"
            else:
                perf = "High"
        else:
            perf = str(df.loc[i, target])

        # 🎯 recommendations
        if perf == "Low":
            rec = "Needs immediate attention and extra support."
        elif perf == "Medium":
            rec = "Monitor progress and provide targeted help."
        else:  # High
            rec = "Performing well, encourage to continue."

        # 🔥 NEW: Add score and separate fields
        results.append({
            "id": i,
            "performance": perf,
            "risk": risk_score,
            "score": f"{val:.2f}" if pd.notna(val) else df.loc[i, target],
            "recommendation": rec,
            "strengths": strengths,
            "weaknesses": weaknesses
        })

    return results

# =====================
# AUTH
# =====================
@app.route("/")
def home():
    return redirect("/login")

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.cookies.get('token')
        if not token:
            return redirect('/login')
        try:
            jwt.decode(token, app.secret_key, algorithms=["HS256"])
        except:
            return redirect('/login')
        return f(*args, **kwargs)
    return decorated

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        if users.get(username) == request.form["password"]:
            token = jwt.encode({
                'user': username,
                'exp': datetime.now(timezone.utc) + timedelta(days=30)
            }, app.secret_key, algorithm="HS256")

            resp = make_response(redirect("/dashboard"))
            # Set cookie to be persistent for 30 days
            resp.set_cookie('token', token, httponly=True, samesite='Lax', max_age=timedelta(days=30).total_seconds())
            return resp
        return "Invalid credentials ❌"
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        users[request.form["username"]] = request.form["password"]
        return redirect("/login")
    return render_template("register.html")

@app.route("/logout")
def logout():
    resp = make_response(redirect("/login"))
    resp.set_cookie('token', '', expires=0)
    return resp

# =====================
# DASHBOARD
# =====================
@app.route("/dashboard")
@token_required
def dashboard():
    return render_template("dashboard.html")

# =====================
# UPLOAD + TRAIN + PREDICT
# =====================
@app.route("/upload", methods=["GET", "POST"])
@token_required
def upload():

    if request.method == "POST":

        file = request.files.get("file")

        if not file or file.filename == "":
            return "No file uploaded ❌"

        filename = secure_filename(file.filename)
        path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(path)

        # Load CSV safely
        try:
            df = pd.read_csv(path, sep=None, engine='python')
        except:
            df = pd.read_csv(path)

        try:
            X, y, scaler, encoders, is_classification, feature_names = preprocess_data(df)

            # 🔥 FIX 1: Stable split
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )

            if is_classification:
                model = RandomForestClassifier(random_state=42)
                metric_name = "Cross-Validation Accuracy"
            else:
                model = RandomForestRegressor(random_state=42)
                metric_name = "Cross-Validation R2 Score"

            # 🔥 FIX 2: CROSS VALIDATION (main upgrade)
            scores = cross_val_score(model, X, y, cv=5)

            score = round(scores.mean(), 3)

            # 🔥 Train final model
            model.fit(X_train, y_train)

            # Feature Importance
            if hasattr(model, 'feature_importances_'):
                importances = model.feature_importances_
                feature_importance_df = pd.DataFrame({
                    'feature': feature_names,
                    'importance': importances
                })
                feature_importance_df = feature_importance_df.sort_values(
                    'importance', ascending=False
                ).head(10)

                plt.figure(figsize=(6, 4))
                plt.barh(feature_importance_df['feature'], feature_importance_df['importance'], color='#43aa8b')
                plt.xlabel("Importance")
                plt.title("Top 10 Feature Importances")
                plt.gca().invert_yaxis()
                plt.tight_layout()
                plt.savefig("static/graphs/feature_importance.png")
                plt.close()

            # Predictions
            preds = model.predict(X_test)
            pred_value = preds[0]

            # Interpret prediction
            if is_classification:
                pred_label = f"Class {pred_value}"
                pred_desc = "Predicted category based on student performance"
            else:
                pred_label = round(float(pred_value), 2)

                q33 = df.iloc[:, -1].quantile(0.33)
                q66 = df.iloc[:, -1].quantile(0.66)
                if pred_value < q33:
                    pred_desc = "Low predicted performance"
                elif pred_value < q66:
                    pred_desc = "Medium predicted performance"
                else:
                    pred_desc = "High predicted performance"

        except Exception as e:
            return f"Processing error: {str(e)} ❌"

        # Graphs
        plot_prediction(df)
        plot_class_distribution(df)
        

        # Insights
        insights = analyze_patterns(df)
        student_analysis = analyze_students(df)
        plot_student_performance(student_analysis)
        return render_template( # sourcery skip: inline-immediately-returned-variable
            "results.html",
            table=df.to_html(classes="data-table", index=False),
            prediction=pred_label, # type: ignore
            prediction_desc=pred_desc,
            insights=insights,
            student_analysis=student_analysis,
            score=score,
            metric=metric_name
        )
        
    


    return render_template("upload.html")

# =====================
# RUN
# =====================
if __name__ == "__main__":
    app.run(debug=True)